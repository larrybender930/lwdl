require('dotenv').config();
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const http = require('http');
const https = require('https');
const { decryptStreamToken } = require('./utils/streamProxy');

const app = express();
const PORT = process.env.PORT;

// Connection pooling for better performance with multiple concurrent users
const httpAgent = new http.Agent({
  keepAlive: true,
  keepAliveMsecs: 30000,
  maxSockets: 1000, // Allow 1000 concurrent connections per host
  maxFreeSockets: 10,
  timeout: 60000,
});

const httpsAgent = new https.Agent({
  keepAlive: true,
  keepAliveMsecs: 30000,
  maxSockets: 1000, // Allow 1000 concurrent connections per host
  maxFreeSockets: 10,
  timeout: 60000,
});

// Track active downloads and streams for monitoring
let activeDownloads = 0;
let activeStreams = 0;

// Enable CORS for frontend
app.use(cors({
  origin: process.env.FRONTEND_URL,
  credentials: true
}));

app.use(express.json());

// Helper function to generate HTML error pages
const renderErrorPage = (title, message, statusCode) => {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title} - Lugawatch</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      padding: 20px;
    }
    .container {
      max-width: 600px;
      text-align: center;
    }
    .error-icon {
      width: 120px;
      height: 120px;
      margin: 0 auto 30px;
      background: rgba(239, 68, 68, 0.1);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 3px solid rgba(239, 68, 68, 0.3);
    }
    .error-icon svg {
      width: 60px;
      height: 60px;
      color: #ef4444;
    }
    .status-code {
      font-size: 72px;
      font-weight: bold;
      background: linear-gradient(135deg, #ef4444, #dc2626);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin-bottom: 20px;
    }
    h1 {
      font-size: 32px;
      margin-bottom: 15px;
      font-weight: 600;
    }
    p {
      font-size: 16px;
      color: #94a3b8;
      line-height: 1.6;
      margin-bottom: 30px;
    }
    .button {
      display: inline-block;
      padding: 14px 32px;
      background: linear-gradient(135deg, #ef4444, #dc2626);
      color: white;
      text-decoration: none;
      border-radius: 8px;
      font-weight: 600;
      transition: transform 0.2s, box-shadow 0.2s;
      box-shadow: 0 4px 14px rgba(239, 68, 68, 0.4);
    }
    .button:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(239, 68, 68, 0.5);
    }
    .footer {
      margin-top: 40px;
      font-size: 14px;
      color: #64748b;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="error-icon">
      <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
      </svg>
    </div>
    <div class="status-code">${statusCode}</div>
    <h1>${title}</h1>
    <p>${message}</p>
    <a href="javascript:window.close()" class="button">Close This Tab</a>
    <div class="footer">
      Lugawatch Download Service
    </div>
  </div>
</body>
</html>
  `;
};

// Health check endpoint with stats
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    service: 'lugawatch-downloader',
    activeDownloads: activeDownloads,
    activeStreams: activeStreams,
    uptime: process.uptime(),
    memory: {
      used: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
      total: Math.round(process.memoryUsage().heapTotal / 1024 / 1024),
    }
  });
});

// Stream proxy endpoint - serves encrypted stream URLs
app.get('/stream/:token', async (req, res) => {
  activeStreams++;
  let streamComplete = false;
  
  // Cleanup function to ensure counter is decremented only once
  const cleanup = () => {
    if (!streamComplete) {
      streamComplete = true;
      activeStreams = Math.max(0, activeStreams - 1);
    }
  };
  
  try {
    const { token } = req.params;
    
    // Decrypt and validate the token
    const streamUrl = decryptStreamToken(token);
    
    if (!streamUrl) {
      cleanup();
      return res.status(403).json({ 
        error: 'Invalid or expired stream token',
        message: 'The stream token is invalid or has expired. Please refresh the page and try again.'
      });
    }
    
    // Validate URL format
    try {
      new URL(streamUrl);
    } catch (err) {
      cleanup();
      return res.status(400).json({ 
        error: 'Invalid URL',
        message: 'The stream URL format is invalid.'
      });
    }
    
    // Fetch the stream from the original source with connection pooling
    const response = await axios({
      method: 'GET',
      url: streamUrl,
      responseType: 'stream',
      timeout: 30000, // 30 seconds timeout for streams
      headers: {
        'Range': req.headers.range || '', // Support range requests for video seeking
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
      httpAgent: httpAgent,
      httpsAgent: httpsAgent,
    });
    
    // Set appropriate headers for video streaming
    res.setHeader('Content-Type', response.headers['content-type'] || 'video/mp4');
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Cache-Control', 'public, max-age=3600'); // Cache for 1 hour
    
    // Pass through content-length and range headers if present
    if (response.headers['content-length']) {
      res.setHeader('Content-Length', response.headers['content-length']);
    }
    if (response.headers['content-range']) {
      res.setHeader('Content-Range', response.headers['content-range']);
      res.status(206); // Partial Content
    }
    
    // Pipe the stream data to the response
    response.data.pipe(res);
    
    // Clean up on client disconnect
    req.on('close', () => {
      if (!res.writableEnded) {
        response.data.destroy();
      }
      cleanup();
    });

    // Handle errors in the stream
    response.data.on('error', (error) => {
      console.error('Stream error:', error);
      if (!res.headersSent) {
        res.status(500).json({ 
          error: 'Stream error',
          message: 'An error occurred while streaming the video.'
        });
      } else if (!res.writableEnded) {
        res.end();
      }
      cleanup();
    });
    
    // Handle successful completion
    response.data.on('end', () => {
      cleanup();
    });
    
  } catch (error) {
    console.error('Stream proxy error:', error.message);
    cleanup();
    
    if (!res.headersSent) {
      // Handle specific errors
      if (error.response?.status === 404) {
        return res.status(404).json({ 
          error: 'Stream not found',
          message: 'The video stream could not be found.'
        });
      }
      if (error.response?.status === 416) {
        return res.status(416).json({ 
          error: 'Range not satisfiable',
          message: 'The requested video range is not valid.'
        });
      }
      if (error.code === 'ECONNABORTED') {
        return res.status(504).json({ 
          error: 'Connection timeout',
          message: 'The server took too long to respond.'
        });
      }
      
      res.status(500).json({ 
        error: 'Failed to fetch stream',
        message: 'An unexpected error occurred while streaming the video.'
      });
    }
  }
});

// Download proxy endpoint with resumable download support
// Uses encrypted token (same as /stream) to prevent open proxy abuse
app.get('/download/:token', async (req, res) => {
  activeDownloads++;
  let downloadComplete = false;
  
  // Cleanup function to ensure counter is decremented only once
  const cleanup = () => {
    if (!downloadComplete) {
      downloadComplete = true;
      activeDownloads = Math.max(0, activeDownloads - 1);
    }
  };
  
  try {
    const { token } = req.params;
    const { filename } = req.query;

    // Decrypt and validate the token (same as stream endpoint)
    const videoUrl = decryptStreamToken(token);
    
    if (!videoUrl) {
      cleanup();
      return res.status(403).send(
        renderErrorPage(
          'Invalid or Expired Link',
          'This download link is invalid or has expired. Please go back to Lugawatch and try downloading again.',
          403
        )
      );
    }

    // Validate URL format
    try {
      new URL(videoUrl);
    } catch (err) {
      cleanup();
      return res.status(400).send(
        renderErrorPage(
          'Invalid URL',
          'The download URL format is invalid. Please try again from the Lugawatch app.',
          400
        )
      );
    }

    const downloadFilename = filename || 'video.mp4';
    
    // Check if this is a range request (for resumable downloads)
    const range = req.headers.range;

    // Cleanup on client disconnect
    req.on('close', () => {
      cleanup();
    });

    // Fetch the video from the source with range support
    const axiosConfig = {
      method: 'GET',
      url: videoUrl,
      responseType: 'stream',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
      // Only timeout for initial connection, not for the entire download
      timeout: 30000, // 30 seconds to establish connection
      validateStatus: (status) => {
        // Accept 200 (OK) and 206 (Partial Content) as valid responses
        return status === 200 || status === 206;
      },
      maxRedirects: 5,
      httpAgent: httpAgent,
      httpsAgent: httpsAgent,
    };

    // Forward the Range header if present (for resumable downloads)
    if (range) {
      axiosConfig.headers['Range'] = range;
    }

    const response = await axios(axiosConfig);

    // Set headers for download with resumable support
    res.setHeader('Content-Type', response.headers['content-type'] || 'video/mp4');
    res.setHeader('Content-Disposition', `attachment; filename="${downloadFilename}"`);
    
    // Forward ETag if present (helps browsers verify they're resuming the same file)
    if (response.headers['etag']) {
      res.setHeader('ETag', response.headers['etag']);
    }
    
    // Forward Last-Modified if present (also helps with resume validation)
    if (response.headers['last-modified']) {
      res.setHeader('Last-Modified', response.headers['last-modified']);
    }
    
    // Only advertise Accept-Ranges if the upstream source supports it
    // Check if upstream returned Accept-Ranges header or if we got a 206 response
    if (response.headers['accept-ranges'] === 'bytes' || response.status === 206) {
      res.setHeader('Accept-Ranges', 'bytes'); // Enable resumable downloads
    } else if (!range) {
      // For initial requests (no range), we can still advertise ranges optimistically
      res.setHeader('Accept-Ranges', 'bytes');
    }
    
    // Copy content-length if available
    if (response.headers['content-length']) {
      res.setHeader('Content-Length', response.headers['content-length']);
    }

    // Handle partial content response (206)
    if (response.status === 206 && response.headers['content-range']) {
      res.status(206); // Partial Content
      res.setHeader('Content-Range', response.headers['content-range']);
    }

    // Set cache headers
    res.setHeader('Cache-Control', 'no-cache');

    // Pipe the video stream to the response
    response.data.pipe(res);

    // Handle errors in the stream
    response.data.on('error', (error) => {
      console.error('Stream error:', error);
      // Just end the response, don't try to send error page
      // The browser will automatically retry with Range header if resume is supported
      if (!res.writableEnded) {
        res.end();
      }
    });

    // Handle successful completion
    response.data.on('end', () => {
      if (!res.writableEnded) {
        res.end();
      }
      cleanup();
    });

    // Handle client disconnect (when user closes/cancels download)
    req.on('close', () => {
      if (!res.writableEnded) {
        response.data.destroy();
      }
    });

  } catch (error) {
    console.error('Download proxy error:', error.message);
    cleanup();
    
    if (!res.headersSent) {
      if (error.response) {
        // Handle specific HTTP status codes
        if (error.response.status === 416) {
          // Range Not Satisfiable - the requested range is invalid
          res.status(416).send(
            renderErrorPage(
              'Invalid Range',
              'The requested download range is invalid. The download will restart from the beginning.',
              416
            )
          );
        } else if (error.response.status === 404) {
          res.status(404).send(
            renderErrorPage(
              'Video Not Found',
              'The video could not be found or accessed. It may have been removed or the link has expired.',
              404
            )
          );
        } else {
          res.status(error.response.status).send(
            renderErrorPage(
              'Video Not Found',
              'The video could not be found or accessed. It may have been removed or the link has expired.',
              error.response.status
            )
          );
        }
      } else if (error.code === 'ECONNABORTED') {
        res.status(504).send(
          renderErrorPage(
            'Connection Timeout',
            'The server took too long to respond. Please check your internet connection and try again.',
            504
          )
        );
      } else if (error.code === 'ECONNREFUSED') {
        res.status(500).send(
          renderErrorPage(
            'Server Unavailable',
            'Unable to connect to the video server. The video may be temporarily unavailable.',
            500
          )
        );
      } else {
        res.status(500).send(
          renderErrorPage(
            'Download Error',
            'An unexpected error occurred while processing your download. Please try again later.',
            500
          )
        );
      }
    }
  }
});

// 404 handler for unknown routes
app.use((req, res) => {
  res.status(404).send(
    renderErrorPage(
      'Page Not Found',
      'The page you are looking for does not exist. Please use the download links from Lugawatch.',
      404
    )
  );
});

app.listen(PORT, () => {
  console.log(`Download proxy server running on http://localhost:${PORT}`);
});

