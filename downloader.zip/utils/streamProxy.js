const crypto = require('crypto');

// Encryption settings
const ALGORITHM = 'aes-256-cbc';
const SECRET_KEY = 'your-secret-key-change-this-in-production-just-for-show';
const IV_LENGTH = 16;

/**
 * Decrypts and validates a stream token
 * Returns the original URL if valid and not expired, null otherwise
 */
const decryptStreamToken = (token) => {
  if (!token) return null;
  
  try {
    // Decode from URL-safe base64
    const base64 = token
      .replace(/-/g, '+')
      .replace(/_/g, '/');
    
    // Add padding if needed
    const padding = '='.repeat((4 - base64.length % 4) % 4);
    const encryptedData = Buffer.from(base64 + padding, 'base64').toString('utf8');
    
    // Split IV and encrypted content
    const parts = encryptedData.split(':');
    if (parts.length !== 2) {
      return null;
    }
    
    const iv = Buffer.from(parts[0], 'hex');
    const encrypted = parts[1];
    
    // Ensure the key is exactly 32 bytes for AES-256
    const key = crypto.createHash('sha256').update(SECRET_KEY).digest();
    
    // Create decipher and decrypt
    const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    // Parse the payload
    const payload = JSON.parse(decrypted);
    
    // Check if token has expired
    const currentTime = Math.floor(Date.now() / 1000);
    if (payload.exp < currentTime) {
      console.log('Stream token expired');
      return null;
    }
    
    return payload.url;
  } catch (error) {
    console.error('Stream decryption error:', error.message);
    return null;
  }
};

module.exports = {
  decryptStreamToken,
};
